#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objidl.h>
#include <gdiplus.h>
#include <commdlg.h>
#include <mmsystem.h>
#include <richedit.h>

#include <string>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
#include <cmath>

#pragma comment(lib,"gdiplus.lib")
#pragma comment(lib,"winmm.lib")

using namespace Gdiplus;

// ================= GLOBAL =================
HWND hEditor, hConsole, hMain, hImage;
std::string current_code;

std::map<std::string,double> vars;
std::string waitingVar;

ULONG_PTR gdiplusToken;
Gdiplus::Image* gImage = nullptr;

// ================= UTILS =================
std::string trim(const std::string& s){
    size_t a=s.find_first_not_of(" \t\r\n");
    if(a==std::string::npos) return "";
    size_t b=s.find_last_not_of(" \t\r\n");
    return s.substr(a,b-a+1);
}
std::string lower(std::string s){
    for(char& c:s) c=tolower(c);
    return s;
}
std::string exeDir(){
    char p[MAX_PATH];
    GetModuleFileNameA(NULL,p,MAX_PATH);
    std::string s=p;
    return s.substr(0,s.find_last_of("\\/"));
}

// ================= CONSOLE COLOR =================
void appendText(const std::string& txt, COLORREF color){
    CHARRANGE cr={-1,-1};
    SendMessage(hConsole,EM_EXSETSEL,0,(LPARAM)&cr);

    CHARFORMAT2 cf={0};
    cf.cbSize=sizeof(cf);
    cf.dwMask=CFM_COLOR;
    cf.crTextColor=color;

    SendMessage(hConsole,EM_SETCHARFORMAT,SCF_SELECTION,(LPARAM)&cf);
    SendMessage(hConsole,EM_REPLACESEL,0,(LPARAM)txt.c_str());
}

// ================= SOUND =================
void play_sound(const std::string& file){
    std::string full=exeDir()+"\\"+file;
    if(GetFileAttributesA(full.c_str())==INVALID_FILE_ATTRIBUTES){
        MessageBoxA(hMain,full.c_str(),"Sound not found",MB_ICONERROR);
        return;
    }
    char shortPath[MAX_PATH];
    GetShortPathNameA(full.c_str(),shortPath,MAX_PATH);
    std::string path=shortPath;

    std::string ext=lower(path.substr(path.find_last_of('.')+1));
    if(ext=="wav"){
        PlaySoundA(path.c_str(),NULL,SND_FILENAME|SND_ASYNC);
        return;
    }
    mciSendStringA("close mysound",NULL,0,NULL);
    std::string cmd="open \""+path+"\" type mpegvideo alias mysound";
    mciSendStringA(cmd.c_str(),NULL,0,NULL);
    mciSendStringA("play mysound",NULL,0,NULL);
}

// ================= IMAGE =================
void loadImage(const std::string& path){
    if(GetFileAttributesA(path.c_str())==INVALID_FILE_ATTRIBUTES){
        MessageBoxA(hMain,"FILE KHÔNG TỒN TẠI",path.c_str(),MB_ICONERROR);
        return;
    }
    if(gImage){ delete gImage; gImage=nullptr; }

    std::wstring w(path.begin(),path.end());
    gImage = Gdiplus::Image::FromFile(w.c_str(),FALSE);

    if(!gImage || gImage->GetLastStatus()!=Ok){
        MessageBoxA(hMain,"LOAD IMAGE FAIL",path.c_str(),MB_ICONERROR);
        delete gImage; gImage=nullptr;
        return;
    }
    InvalidateRect(hImage,NULL,TRUE);
}

// ================= FILE =================
void open_file(){
    char name[MAX_PATH]="";
    OPENFILENAMEA ofn={sizeof(ofn)};
    ofn.lpstrFilter="MySelf (*.myself)\0*.myself\0All\0*.*\0";
    ofn.lpstrFile=name;
    ofn.nMaxFile=MAX_PATH;
    ofn.Flags=OFN_FILEMUSTEXIST;

    if(GetOpenFileNameA(&ofn)){
        std::ifstream f(name);
        std::stringstream ss;
        ss<<f.rdbuf();
        current_code=ss.str();
        SetWindowTextA(hEditor,current_code.c_str());
    }
}
void save_file(){
    char name[MAX_PATH]="MySelfFile.myself";
    OPENFILENAMEA ofn={sizeof(ofn)};
    ofn.lpstrFilter="MySelf (*.myself)\0*.myself\0";
    ofn.lpstrFile=name;
    ofn.nMaxFile=MAX_PATH;
    ofn.lpstrDefExt="myself";
    ofn.Flags=OFN_OVERWRITEPROMPT;

    if(GetSaveFileNameA(&ofn)){
        std::ofstream f(name);
        f<<current_code;
    }
}

// ================= MATH =================
double eval(const std::string& e){
    std::string s=trim(e);
    if(vars.count(s)) return vars[s];

    char* end;
    double v=strtod(s.c_str(),&end);
    if(end!=s.c_str() && *end==0) return v;

    if(s.find("sqrt(")==0) return sqrt(eval(s.substr(5,s.size()-6)));
    if(s.find("sin(")==0) return sin(eval(s.substr(4,s.size()-5)));
    if(s.find("cos(")==0) return cos(eval(s.substr(4,s.size()-5)));
    if(s.find("tan(")==0) return tan(eval(s.substr(4,s.size()-5)));
    if(s.find("abs(")==0) return fabs(eval(s.substr(4,s.size()-5)));
    if(s.find("pow(")==0){
        auto in=s.substr(4,s.size()-5);
        auto p=in.find(',');
        return pow(eval(in.substr(0,p)),eval(in.substr(p+1)));
    }
    if(s=="rand()") return rand()%100;
    return 0;
}
bool isString(const std::string& s)
{
    return s.size() >= 2 &&
           ((s.front() == '"' && s.back() == '"') ||
            (s.front() == '\'' && s.back() == '\''));
}

std::string toString(double v)
{
    std::ostringstream oss;
    oss << v;
    return oss.str();
}

// ================= INTERPRETER =================
void run_code(){
    vars.clear();
    waitingVar.clear();

    std::stringstream ss(current_code);
    std::string line;

    while(std::getline(ss, line)){
        line = trim(line);
        if(line.empty()) continue;

        // ===== out() =====
        if(line.find("out(") == 0){
            std::string c = trim(line.substr(4, line.size() - 5));

            if(isString(c)){
                appendText(
                    c.substr(1, c.size() - 2) + "\r\n",
                    RGB(255,255,255)
                );
            }else{
                appendText(
                    toString(eval(c)) + "\r\n",
                    RGB(255,255,255)
                );
            }
        }

        // ===== playsound() =====
        else if(line.find("playsound(") == 0){
            std::string f = line.substr(10, line.size() - 11);
            play_sound(f.substr(1, f.size() - 2));
        }

        // ===== usefileimage() =====
        else if(line.find("usefileimage(") == 0){
            std::string p = line.substr(13, line.size() - 14);
            loadImage(p.substr(1, p.size() - 2));
        }

        // ===== in(var, "msg") =====
        else if(line.find("in(") == 0){
            auto p1 = line.find('(');
            auto p2 = line.find(',');
            auto p3 = line.rfind(')');

            waitingVar = trim(line.substr(p1 + 1, p2 - p1 - 1));

            std::string msg =
                trim(line.substr(p2 + 1, p3 - p2 - 1));

            if(isString(msg))
                msg = msg.substr(1, msg.size() - 2);

            appendText(msg + " ", RGB(0,255,0));
            return; // dừng để chờ nhập
        }

        // ===== gán biến =====
        else if(line.find('=') != std::string::npos){
            auto p = line.find('=');
            vars[trim(line.substr(0, p))] =
                eval(line.substr(p + 1));
        }
    }
}


// ================= IMAGE WINDOW PROC =================
LRESULT CALLBACK ImageProc(HWND h,UINT m,WPARAM w,LPARAM l){
    if(m==WM_PAINT){
        PAINTSTRUCT ps;
        HDC hdc=BeginPaint(h,&ps);
        if(gImage){
            Graphics g(hdc);
            RECT r; GetClientRect(h,&r);
            g.DrawImage(gImage,0,0,r.right,r.bottom);
        }
        EndPaint(h,&ps);
        return 0;
    }
    return DefWindowProc(h,m,w,l);
}

// ================= MAIN WINDOW =================
LRESULT CALLBACK WndProc(HWND h,UINT m,WPARAM w,LPARAM l){
    switch(m){
    case WM_COMMAND:
        if(LOWORD(w)==1){
            int n=GetWindowTextLengthA(hEditor);
            char* b=new char[n+1];
            GetWindowTextA(hEditor,b,n+1);
            current_code=b; delete[] b;
            SetWindowTextA(hConsole,"");
            run_code();
        }
        if(LOWORD(w)==2) open_file();
        if(LOWORD(w)==3) save_file();
        break;

    case WM_CHAR:
        if(w==VK_RETURN && !waitingVar.empty()){
            char buf[256];
            GetWindowTextA(hConsole,buf,255);
            vars[waitingVar]=atof(strrchr(buf,' ')+1);
            waitingVar.clear();
            appendText("\r\n",RGB(255,255,255));
            run_code();
        }
        break;

    case WM_DESTROY:
        mciSendStringA("close mysound",NULL,0,NULL);
        PostQuitMessage(0);
        break;
    }
    return DefWindowProc(h,m,w,l);
}

// ================= WinMain =================
int WINAPI WinMain(HINSTANCE h, HINSTANCE, LPSTR, int n){
    LoadLibraryA("Msftedit.dll");

    GdiplusStartupInput gd;
    GdiplusStartup(&gdiplusToken,&gd,NULL);

    WNDCLASS wc={}, wcImg={};
    wc.lpfnWndProc=WndProc;
    wc.hInstance=h;
    wc.lpszClassName="MySelfIDE";
    RegisterClass(&wc);

    wcImg.lpfnWndProc=ImageProc;
    wcImg.hInstance=h;
    wcImg.lpszClassName="ImageWindow";
    RegisterClass(&wcImg);

    hMain=CreateWindow("MySelfIDE","MySelf IDE",
        WS_OVERLAPPEDWINDOW,100,100,800,600,
        NULL,NULL,h,NULL);

    hImage=CreateWindowEx(
        WS_EX_TOPMOST,
        "ImageWindow","",
        WS_CHILD|WS_VISIBLE,
        450,40,320,240,
        hMain,NULL,h,NULL);

    hEditor=CreateWindowEx(WS_EX_CLIENTEDGE,"EDIT","",
        WS_CHILD|WS_VISIBLE|ES_MULTILINE|WS_VSCROLL,
        10,40,420,300,hMain,NULL,h,NULL);

    hConsole=CreateWindowEx(WS_EX_CLIENTEDGE,"EDIT","",
        WS_CHILD|WS_VISIBLE|ES_MULTILINE|WS_VSCROLL,
        10,350,760,200,hMain,NULL,h,NULL);

    HFONT font=CreateFontA(16,0,0,0,FW_NORMAL,0,0,0,
        ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY,FF_DONTCARE,"Consolas");

    SendMessage(hEditor,WM_SETFONT,(WPARAM)font,TRUE);
    SendMessage(hConsole,WM_SETFONT,(WPARAM)font,TRUE);

    CreateWindow("BUTTON","Run",WS_CHILD|WS_VISIBLE,10,10,60,25,hMain,(HMENU)1,h,NULL);
    CreateWindow("BUTTON","Open",WS_CHILD|WS_VISIBLE,80,10,60,25,hMain,(HMENU)2,h,NULL);
    CreateWindow("BUTTON","Save",WS_CHILD|WS_VISIBLE,150,10,60,25,hMain,(HMENU)3,h,NULL);

    ShowWindow(hMain,n);
    UpdateWindow(hMain);

    MSG msg;
    while(GetMessage(&msg,NULL,0,0)){
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}
